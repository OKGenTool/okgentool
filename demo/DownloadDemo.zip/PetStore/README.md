This is a Kotlin Multiplatform project targeting Server.

* `/server` is for the Ktor server application.


Learn more about [Kotlin Multiplatform](https://www.jetbrains.com/help/kotlin-multiplatform-dev/get-started.html)…